# -*- coding: utf-8 -*-

# Form implementation generated from reading ui file 'randint.ui'
#
# Created: Tue Jan 12 18:12:10 2016
#      by: PyQt4 UI code generator 4.10.4
#
# WARNING! All changes made in this file will be lost!

