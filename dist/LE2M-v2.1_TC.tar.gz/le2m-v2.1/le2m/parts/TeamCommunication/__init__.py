import TeamCommunicationPart  # for sqlalchemy
