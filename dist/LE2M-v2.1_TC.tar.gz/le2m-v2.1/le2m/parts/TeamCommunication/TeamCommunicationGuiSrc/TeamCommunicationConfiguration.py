# -*- coding: utf-8 -*-

# Form implementation generated from reading ui file 'TeamCommunicationConfiguration.ui'
#
# Created: Sat Oct 31 13:21:25 2015
#      by: PyQt4 UI code generator 4.10.4
#
# WARNING! All changes made in this file will be lost!

from PyQt4 import QtCore, QtGui

try:
    _fromUtf8 = QtCore.QString.fromUtf8
except AttributeError:
    def _fromUtf8(s):
        return s

try:
    _encoding = QtGui.QApplication.UnicodeUTF8
    def _translate(context, text, disambig):
        return QtGui.QApplication.translate(context, text, disambig, _encoding)
except AttributeError:
    def _translate(context, text, disambig):
        return QtGui.QApplication.translate(context, text, disambig)

class Ui_Dialog(object):
    def setupUi(self, Dialog):
        Dialog.setObjectName(_fromUtf8("Dialog"))
        Dialog.resize(370, 148)
        self.verticalLayout = QtGui.QVBoxLayout(Dialog)
        self.verticalLayout.setObjectName(_fromUtf8("verticalLayout"))
        self.horizontalLayout_4 = QtGui.QHBoxLayout()
        self.horizontalLayout_4.setObjectName(_fromUtf8("horizontalLayout_4"))
        spacerItem = QtGui.QSpacerItem(40, 20, QtGui.QSizePolicy.Expanding, QtGui.QSizePolicy.Minimum)
        self.horizontalLayout_4.addItem(spacerItem)
        self.formLayout = QtGui.QFormLayout()
        self.formLayout.setObjectName(_fromUtf8("formLayout"))
        self.label_tempspartie = QtGui.QLabel(Dialog)
        self.label_tempspartie.setObjectName(_fromUtf8("label_tempspartie"))
        self.formLayout.setWidget(0, QtGui.QFormLayout.LabelRole, self.label_tempspartie)
        self.horizontalLayout_3 = QtGui.QHBoxLayout()
        self.horizontalLayout_3.setObjectName(_fromUtf8("horizontalLayout_3"))
        self.timeEdit_tempspartie = QtGui.QTimeEdit(Dialog)
        self.timeEdit_tempspartie.setObjectName(_fromUtf8("timeEdit_tempspartie"))
        self.horizontalLayout_3.addWidget(self.timeEdit_tempspartie)
        spacerItem1 = QtGui.QSpacerItem(40, 20, QtGui.QSizePolicy.Expanding, QtGui.QSizePolicy.Minimum)
        self.horizontalLayout_3.addItem(spacerItem1)
        self.formLayout.setLayout(0, QtGui.QFormLayout.FieldRole, self.horizontalLayout_3)
        self.label_communication = QtGui.QLabel(Dialog)
        self.label_communication.setObjectName(_fromUtf8("label_communication"))
        self.formLayout.setWidget(1, QtGui.QFormLayout.LabelRole, self.label_communication)
        self.horizontalLayout = QtGui.QHBoxLayout()
        self.horizontalLayout.setObjectName(_fromUtf8("horizontalLayout"))
        self.comboBox_communication = QtGui.QComboBox(Dialog)
        self.comboBox_communication.setObjectName(_fromUtf8("comboBox_communication"))
        self.horizontalLayout.addWidget(self.comboBox_communication)
        spacerItem2 = QtGui.QSpacerItem(40, 20, QtGui.QSizePolicy.Expanding, QtGui.QSizePolicy.Minimum)
        self.horizontalLayout.addItem(spacerItem2)
        self.formLayout.setLayout(1, QtGui.QFormLayout.FieldRole, self.horizontalLayout)
        self.label_grilles = QtGui.QLabel(Dialog)
        self.label_grilles.setObjectName(_fromUtf8("label_grilles"))
        self.formLayout.setWidget(2, QtGui.QFormLayout.LabelRole, self.label_grilles)
        self.horizontalLayout_2 = QtGui.QHBoxLayout()
        self.horizontalLayout_2.setObjectName(_fromUtf8("horizontalLayout_2"))
        self.pushButton_grilles = QtGui.QPushButton(Dialog)
        self.pushButton_grilles.setObjectName(_fromUtf8("pushButton_grilles"))
        self.horizontalLayout_2.addWidget(self.pushButton_grilles)
        self.label_grilles_nb = QtGui.QLabel(Dialog)
        self.label_grilles_nb.setObjectName(_fromUtf8("label_grilles_nb"))
        self.horizontalLayout_2.addWidget(self.label_grilles_nb)
        spacerItem3 = QtGui.QSpacerItem(40, 20, QtGui.QSizePolicy.Expanding, QtGui.QSizePolicy.Minimum)
        self.horizontalLayout_2.addItem(spacerItem3)
        self.formLayout.setLayout(2, QtGui.QFormLayout.FieldRole, self.horizontalLayout_2)
        self.horizontalLayout_4.addLayout(self.formLayout)
        spacerItem4 = QtGui.QSpacerItem(40, 20, QtGui.QSizePolicy.Expanding, QtGui.QSizePolicy.Minimum)
        self.horizontalLayout_4.addItem(spacerItem4)
        self.verticalLayout.addLayout(self.horizontalLayout_4)
        self.buttonBox = QtGui.QDialogButtonBox(Dialog)
        self.buttonBox.setOrientation(QtCore.Qt.Horizontal)
        self.buttonBox.setStandardButtons(QtGui.QDialogButtonBox.Cancel|QtGui.QDialogButtonBox.Ok)
        self.buttonBox.setObjectName(_fromUtf8("buttonBox"))
        self.verticalLayout.addWidget(self.buttonBox)

        self.retranslateUi(Dialog)
        QtCore.QObject.connect(self.buttonBox, QtCore.SIGNAL(_fromUtf8("accepted()")), Dialog.accept)
        QtCore.QObject.connect(self.buttonBox, QtCore.SIGNAL(_fromUtf8("rejected()")), Dialog.reject)
        QtCore.QMetaObject.connectSlotsByName(Dialog)

    def retranslateUi(self, Dialog):
        Dialog.setWindowTitle(_translate("Dialog", "Dialog", None))
        self.label_tempspartie.setText(_translate("Dialog", "Temps partie", None))
        self.timeEdit_tempspartie.setDisplayFormat(_translate("Dialog", "HH:mm:ss", None))
        self.label_communication.setText(_translate("Dialog", "Communication", None))
        self.label_grilles.setText(_translate("Dialog", "Charger les grilles", None))
        self.pushButton_grilles.setText(_translate("Dialog", "Parcourir", None))
        self.label_grilles_nb.setText(_translate("Dialog", "0 grille", None))

