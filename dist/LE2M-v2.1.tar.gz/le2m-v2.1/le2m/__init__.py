# -*- coding: utf-8 -*-
__author__ = "Dimitri DUBOIS"
__version__ = "2.1.0"
