# -*- coding: utf-8 -*-

ECHEC = 0
SUCCES = 1

FEMME = 0
HOMME = 1

FACE = 0
PILE = 1

JOUEUR_A = 0
JOUEUR_B = 1
JOUEUR_C = 2
JOUEUR_D = 3
JOUEUR_E = 4
JOUEUR_F = 5
JOUEUR_G = 6
JOUEUR_H = 7

# pour le type des questions de compréhension
RADIO = 0
CHECKBOX = 1
