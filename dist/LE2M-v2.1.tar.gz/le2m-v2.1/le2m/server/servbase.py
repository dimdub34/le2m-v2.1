# -*- coding: utf-8 -*-
"""
This module is necessary because otherwise servgestbase and servparties
call each other
"""

from sqlalchemy.ext.declarative import declarative_base
from sqlalchemy.orm import sessionmaker

Base = declarative_base()
DB = sessionmaker()
